<div class="header-bottom">
    <div class="card text-white">
        <img class="card-img" src="_img/header_bottom.jpg" alt="Card image">
        <div class="card-img-overlay">
            <h2 class="card-title">DOWNLOADS</h2>
        </div>
    </div>
</div>
</div>
<!------------DOWNLOAD SECTION--------------->

<section class="download-section">
        <div class="container">
            <div class="row mb-5 mt-2">
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Location-Map-Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="_img/icons/icon_downloads_02.svg" alt="image">
                            </div>
                            <div class="card-body">
                                <h4 class="card-text">Location Map The Meadows</h4>
                            </div>
                        </div>
                </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Master-Plan-Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="_img/icons/icon_downloads_01.svg " alt="image">
                            </div>
                            <div class="card-body">
                                <h4 class="card-text">Master Plan The Meadows</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Payment_Schedule_Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="_img/icons/icon_downloads_03.svg" alt="image">
                            </div>
                            <div class="card-body">
                                    <h4 class="card-text">Payment Schedule/Plans</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Flyer.pdf" download>
                    <div class="card">
                        <div class="card-img-top">
                           <img src="_img/icons/icon_downloads_04.svg" alt="image">
                        </div>
                        <div class="card-body">                          
                                <h4 class="card-text">Flyer The Meadows</h4>
                        </div>
                    </div>
                </a>
            </div>
            </div>
        </div>
    </section>




<!-- <section class="download-section">
    <div class="container">
        <div class="download-title">
            <h1>Downloads</h1>
            <hr>
        </div>
        <div class="row mb-5 mt-5">
            <div clas_="col-md-3 col-sm-6 col-6">
                <a href="_img/map/Location-Map-Meadows.pdf" download>
                    <div class="card">
                        <div class="card-img-top">
                            <img src="_img/icons/icon_downloads_02.svg" alt="image">
                        </div>
                        <div class="card-body">
                            <h4 class="card-text">Location Map The Meadows</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <a href="_img/maps/Master-Plan-Meadows.pdf" download>
                    <div class="card">
                        <div class="card-img-top">
                            <img src="_img/icons/icon_downloads_01.svg " alt="image">
                        </div>
                        <div class="card-body">
                            <h4 class="card-text">Master Plan The Meadows</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <a href="_img/maps/Payment_Schedule_Meadows.pdf" download>
                    <div class="card">
                        <div class="card-img-top">
                            <img src="_img/icons/icon_downloads_03.svg" alt="image">
                        </div>
                        <div class="card-body">
                            <h4 class="card-text">Payment Schedule/Plans</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <a href="_img/maps/Flyer.pdf" download>
                    <div class="card">
                        <div class="card-img-top">
                            <img src="_img/icons/icon_downloads_04.svg" alt="image">
                        </div>
                        <div class="card-body">
                            <h4 class="card-text">Flyer The Meadows</h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section> -->

<!---------------------- THE END ---------------------------->