    <!-- ----------FOOTER SECTION ------------ -->

    <div class="contact-section">
        <div class="card bg-dark text-white">
            <img class="card-img" src="_img/footer_bg.jpg" alt="Card image">
            <div class="card-img-overlay">
                <h2 class="card-title">Do You Want Contact To Our Sales Team ?</h2>
                <h5 class="card-text">Contact us now at The Meadows Farm Houses (+92) 333-5933991</h5>
                <div class="contact-btn">
                <a href="callto:+925933991"><button type="button" class="btn btn-light" id="call-us">CALL US</button></a> &nbsp;
                    <a href="mailto:info@themeadows.com.pk"><button type="button" class="btn" style="background-color: #000;">EMAIL US</button></a>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer-section">
        <div class="container">
            <div class="footer-social-icon">
                <ul>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                </ul>
            </div>
            <div class="copy-right">
                <p>Copyrights 2021 The Meadows Farm Houses, Designed & Developd By Swismax Solution All rights reserved
                </p>
            </div>
        </div>
    </footer>

    <!---------------------- THE END ---------------------------->

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="" src="assets/js/owl.carousel.min.js"></script>
    <script type="" src="assets/js/owl.carousel.setting.js"></script>
    <script type="" src="assets/js/main.js"></script>
</body>

</html>