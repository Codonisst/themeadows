
 
    <div class="payment_schedule">
        <div class="container">
            <img src="assets/img/Payment Plan.jpg" alt="">
        </div>
    </div>