<div class="header-bottom">
    <div class="card text-white">
        <img class="card-img" src="_img/header_bottom.jpg" alt="Card image">
        <div class="card-img-overlay">
            <h2 class="card-title">ABM Associates</h2>
        </div>
    </div>
</div>

<section class="aboutus-section mt-5 mb-5" id="abm">
    <div class="container">
        <div class="about-image">
            <img src="_img/abm.svg" alt="abm Logo">
        </div>
        <div class="about-text">
            <h2>ABOUT</h2>
            <h1> ABM ASSOCIATES</h1>
            <div class="row mt-3">
                <div class="col-md-2">

                </div>
                <div class="col-md-8">
                    <p>ABM Associates is a national Real Estate retail broker specialising in agricultural, other commercial and personal insurance risks.</p>
                    <p>Established in 2000 by founder and managing Malik Farooq, ABM Associates is proud to have established a strong reputation within the agricultural and business communities for offering market-leading policies, competitive premiums, and a peerless approach to personal service.</p>
                    <p>Independent and with a client base spanning Great Britain, our success draws from a comprehensive knowledge of the insurance products and services we provide, combined with access to an extensive panel of leading providers and several exclusive schemes.</p>
                </div>
                <div class="col-md-2">

                </div>

            </div>
        </div>

        <!-- <div class="explore-btn">
                        <a href="#"><button type="button" class="btn btn-dark mb-4">Explore More...</button></a>
                    </div> -->
    </div>
</section>