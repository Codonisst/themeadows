    <!------------HERO SECTION--------------->
    <section class="hero-section">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="_img//sliders/slide_1.png" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="_img//sliders/slide_2.jpg" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="_img//sliders/slide_3.jpg" class="d-block w-100" alt="Image">
                </div>
            </div>
        </div>
    </section>

        <!------- Slide For Mobile View --------->
    <section class="hero-section" id="mb_slide">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="_img/sliders/m_slide_01.jpg" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="_img/sliders/m_slide_2.jpg" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="_img/sliders/m_slide_3.jpg" class="d-block w-100" alt="Image">
                </div>
            </div>
        </div>
    </section>
    <!------------ABOUT-US SECTION--------------->

    <section class="aboutus-section mt-3">
        <div class="container">
            <div class="row">
                <div class="col-md">
                    <div class="about-text">
                        <h2>Welcome To</h2>
                        <h1>The Meadows</h1>
                        <span>Farm House</span><br>
                        <P>The Meadows Farmhouses are more than a contemporary residential development. It’s a lifestyle experience that promises the best of community living in an exclusive setting. <br> <br>
                        Plots designed for luxury family lifestyle, adjacent to international standard theme. These farmhouses are the apex of luxury and comfort, providing you a perfect place to experience tranquility and peace. The Meadows Farmhouses are designed with the utmost focus on comfort and with unmatched design quality. Come home to a place that’s a true reflection of your taste and personality.</P>
                        <div class="explore-btn">
                            <a href="index.php?view=about_us"><button type="button" class="btn btn-dark">Explore More...</button></a>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="about-image">
                        <img src="_img/home_aboutus.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!------------DOWNLOAD SECTION--------------->

    <section class="download-section">
        <div class="container">
        <div class="download-title">
                <h1>Downloads</h1>
                <hr>
            </div>
            <div class="row mb-5 mt-5">
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Location-Map-Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="_img/icons/icon_downloads_02.svg" alt="image">
                            </div>
                            <div class="card-body">
                                <h4 class="card-text">Location Map The Meadows</h4>
                            </div>
                        </div>
                </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Master-Plan-Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="_img/icons/icon_downloads_01.svg " alt="image">
                            </div>
                            <div class="card-body">
                                <h4 class="card-text">Master Plan The Meadows</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Payment_Schedule_Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="_img/icons/icon_downloads_03.svg" alt="image">
                            </div>
                            <div class="card-body">
                                    <h4 class="card-text">Payment Schedule/Plans</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="_pdf/Flyer.pdf" download>
                    <div class="card">
                        <div class="card-img-top">
                           <img src="_img/icons/icon_downloads_04.svg" alt="image">
                        </div>
                        <div class="card-body">                          
                                <h4 class="card-text">Flyer The Meadows</h4>
                        </div>
                    </div>
                </a>
            </div>
            </div>
        </div>
    </section>

