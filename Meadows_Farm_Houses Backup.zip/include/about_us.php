

    <div class="header-bottom">
        <div class="card text-white">
            <img class="card-img" src="assets/img/header_bottom.jpg" alt="Card image">
            <div class="card-img-overlay">
                <h2 class="card-title">ABOUT US</h2>
            </div>
        </div>
    </div>

    <section class="aboutus-section mt-3">
        <div class="container">
            <div class="row">
                <div class="col-md">
                    <div class="about-text">
                        <h2>Welcome To</h2>
                        <h1>The Meadows</h1>
                        <span>Farm House</span><br>
                        <p>The Meadows Farmhouses are more than a contemporary residential development. It’s a lifestyle experience that promises the best of community living in an exclusive setting. <p>
                            <p>
                            Plots designed for luxury family lifestyle, adjacent to international standard theme. These farmhouses are the apex of luxury and comfort, providing you a perfect place to experience tranquility and peace. The Meadows Farmhouses are designed with the utmost focus on comfort and with unmatched design quality. Come home to a place that’s a true reflection of your taste and personality.</P>
                        <!-- <div class="explore-btn">
                            <a href="#"><button type="button" class="btn btn-dark">Explore More...</button></a>
                        </div> -->
                    </div>
                </div>
                <div class="col-md">
                    <div class="about-image">
                        <img src="assets/img/home_aboutus.jpg" alt="Image">
                    </div>
                </div>
            </div>
        </div>
    </section>


  