<div class="header-bottom">
    <div class="card text-white">
        <img class="card-img" src="_img/header_bottom.jpg" alt="Card image">
        <div class="card-img-overlay">
            <h2 class="card-title">OUR FEATURES</h2>
        </div>
    </div>
</div>

<section class="features_page">
    <div class="container">
        <center>
            <h1>Our Features</h1>
            <hr>
        </center>
        <div class="row justify-content-center">
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/farmhouse.png" alt="icon Image">
                    </div>
                    <h5>4 to 8 Kanals</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/luxury living.png" alt="icon Image">
                    </div>
                    <h5>Luxurious Living</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/livingcommunity.png" alt="icon Image">
                    </div>
                    <h5>Living Community</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/organic living.png" alt="icon Image">
                    </div>
                    <h5>Organic Living</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/hightechsecurity.png" alt="icon Image">
                    </div>
                    <h5>High Tech Security</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/parks.png" alt="icon Image">
                    </div>
                    <h5>Parks</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/greenspaces.png" alt="icon Image">
                    </div>
                    <h5>Green Spaces</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/perarea.png" alt="icon Image">
                    </div>
                    <h5>Pets Area</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/wideroad.png" alt="icon Image">
                    </div>
                    <h5>Wide Roads</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/mainboulevards.png" alt="icon Image">
                    </div>
                    <h5>Main Boulevards</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2" style="display:none">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/nature.png" alt="icon Image">
                    </div>
                    <h5>High Tech Security</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
            <div class="col-6 col-sm-4 col-md-3 col-lg-2" style="display:none">
                <div class="feature-box">
                    <div class="feature_icon">
                        <img src="assets/icon/nature.png" alt="icon Image">
                    </div>
                    <h5>High Tech Security</h5>
                    <span>Form Houses.</span>
                </div><!-- /.feature-box -->
            </div><!-- /.col-6 col-sm-4 col-md-3 col-lg-2 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section>