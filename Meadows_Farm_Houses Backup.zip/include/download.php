<div class="header-bottom">
        <div class="card text-white">
            <img class="card-img" src="assets/img/header_bottom.jpg" alt="Card image">
            <div class="card-img-overlay">
                <h2 class="card-title">DOWNLOADS</h2>
            </div>
        </div>
    </div>
</div>
     <!------------DOWNLOAD SECTION--------------->   
     <section class="download-section">
        <div class="container">
        <div class="download-title">
                <h1>Downloads</h1>
                <hr>
            </div>
            <div class="row mb-5 mt-5">
                <div class="col-md-3 col-sm-6 col-6">
                <a href="assets/pdf/Location-Map-Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="assets/img/icon_downloads_02.svg" alt="image">
                            </div>
                            <div class="card-body">
                                <h4 class="card-text">Location Map The Meadows</h4>
                            </div>
                        </div>
                </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="assets/pdf/Master-Plan-Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="assets/img/icon_downloads_01.svg " alt="image">
                            </div>
                            <div class="card-body">
                                <h4 class="card-text">Master Plan The Meadows</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="assets/pdf/Payment_Schedule_Meadows.pdf" download>
                        <div class="card">
                            <div class="card-img-top">
                                <img src="assets/img/icon_downloads_03.svg" alt="image">
                            </div>
                            <div class="card-body">
                                    <h4 class="card-text">Payment Schedule/Plans</h4>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                <a href="assets/pdf/Flyer.pdf" download>
                    <div class="card">
                        <div class="card-img-top">
                           <img src="assets/img/icon_downloads_04.svg" alt="image">
                        </div>
                        <div class="card-body">                          
                                <h4 class="card-text">Flyer The Meadows</h4>
                        </div>
                    </div>
                </a>
            </div>
            </div>
        </div>
    </section>

<!---------------------- THE END ---------------------------->
