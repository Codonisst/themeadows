
<?php

include 'phpmailer/class.phpmailer.php';

$Message = '';


if (isset($_POST['submit'])) {

    $contact_fullname             = $_POST['contact_fullname'];
    $contact_email                = $_POST['contact_email'];
    $contact_no                 = $_POST['contact_no'];
    $contact_subject             = $_POST['contact_subject'];
    $contact_message             = $_POST['contact_message'];

    $mail = new PHPMailer;
    //$mail->isSMTP();
    $mail->Host = 'dime180.dizinc.com';
    $mail->Port = 465;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';


    $mail->Username = 'The Meadows Farm houses';
    $mail->Password = 'Pakistan1947';

    $mail->setFrom($_POST['contact_email'], 'The Meadows Farm Houses');
    $mail->addAddress('info@themeadows.pk');
    $mail->addReplyTo($_POST['contact_email']);

    $mail->isHTML(true);
    $mail->Subject = $_POST["contact_subject"];
    $mail->Body = "
 <style>
.Heading {
	color: #ffffff;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 24px;
	font-weight: 100;
	background-color: #000000;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Details {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	padding-top: 10px;
	background-color: #ffffff;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.DetailsMessage {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	background-color: #EEEEEE;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Footer {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	background-color: #DBDBDB;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Footer {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	background-color: #DBDBDB;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Footer a {
	color: #FF0000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	}
</style>

<TABLE style='BORDER-RIGHT: #CCCCCC 1px solid; PADDING-RIGHT: 0px; BORDER-TOP: #CCCCCC 1px solid; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; BORDER-LEFT: #CCCCCC 1px solid; PADDING-TOP: 0px; BORDER-BOTTOM: #CCCCCC 1px solid'
height=238 cellSpacing='0' cellPadding='0' width='800'>
  <tr> 
   <td class='Heading'> <img src='https://themeadows.pk/assets/img/logo.svg'><br>
	The Meadows Farm houses</td>
  </tr>
  <tr>
    <td height='37' class='DetailsMessage'>Contact Details</td>
  </tr>
  <tr>
    <td height='83' bgcolor='#EEEEEE' class='Details'><table width='100%' border='0'>
  <tbody>
    <tr>
      <td width='18%'>Full Name: </td>
      <td width='82%'>$contact_fullname</td>
    </tr>
    <tr>
      <td>Contact No.</td>
      <td>$contact_no</td>
    </tr>
    <tr>
      <td>E-Mail:</td>
      <td>$contact_email</td>
    </tr>
    <tr>
      <td>Subject:</td>
      <td>$contact_subject</td>
    </tr>
  </tbody>
</table></td>
  </tr>
  <tr>
    <td height='40' class='DetailsMessage'>Message: $contact_message</td>
  </tr>
  <tr>
    <td height='40' class='Footer'>This E-Mail Powered by <a href=;http://swismax.com;>Swis MAX Solutions</a></td>
  </tr>
</table>
 ";

    if (!$mail->send()) {
        $Message = "<div class='alert alert-danger'>FAILED - Pease fill all required fileds.</div>";
    } else {
        $Message = "<div class='alert alert-success'>SUCCESS - The form has been successfully submitted.</div>";
    }


    /*--------------------------------------------------------------------------*/



    $mail = new PHPMailer;
    //$mail->isSMTP();
    $mail->Host = 'dime180.dizinc.com';
    $mail->Port = 465;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';


    $mail->Username = 'The Meadows Farm houses';
    $mail->Password = 'Pakistan1947';
    // $mail->Password = 'dbesqyoqbhnzpily';


    $mail->setFrom('info@themeadows.pk', 'The Meadows Farm houses');
    $mail->addAddress($_POST['contact_email']);
    $mail->addReplyTo('info@themeadows.pk');

    $mail->isHTML(true);
    $mail->Subject = "Thankyou For your E-Mail";
    $mail->Body = "
 <style>
.Heading {
	color: #ffffff;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 24px;
	font-weight: 100;
	background-color: #000000;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Details {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	padding-top: 10px;
	background-color: #ffffff;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.DetailsMessage {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	background-color: #EEEEEE;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Footer {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	background-color: #DBDBDB;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Footer {
	color: #000000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	background-color: #DBDBDB;
	padding-top: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-left: 10px;
	}
.Footer a {
	color: #FF0000;
	font-family: Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
	font-size: 14px;
	font-weight: 100;
	}
</style>

<TABLE style='BORDER-RIGHT: #CCCCCC 1px solid; PADDING-RIGHT: 0px; BORDER-TOP: #CCCCCC 1px solid; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; BORDER-LEFT: #CCCCCC 1px solid; PADDING-TOP: 0px; BORDER-BOTTOM: #CCCCCC 1px solid'
height=238 cellSpacing='0' cellPadding='0' width='800'>
  <tr> 
   <td class='Heading'> <img src='https://themeadows.pk/assets/img/logo.svg'><br>
	The Meadows Farm houses</td>
  </tr>
  <tr>
    <td height='40' class='DetailsMessage'>
	<p>Dear $contact_fullname,<br>
	Thankyou for your E-Mail.We will contact you as soon as possible!</p><br>
	<p>Kindest Regards,</strong><br>
    The Meadows Farm houses</strong></p></td>
  </tr>
  <tr>
    <td height='40' class='Footer'>This E-Mail Powered by <a href=;http://swismax.com;>Swis MAX Solutions</a></td>
  </tr>
</table>
 ";

    if (!$mail->send()) {
        echo "";
    } else {

        echo "";
    }
}

?>





<div class="header-bottom">
        <div class="card text-white">
            <img class="card-img" src="_img/header_bottom.jpg" alt="Card image">
            <div class="card-img-overlay">
                <h2 class="card-title">CONTACT US</h2>
            </div>
        </div>
    </div>
</div>

    <div class="ContactDetails">
        <div class="SpacingBox"></div>
        <div class="SpacingBox"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Head Office</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 333 5933991</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 300 5041004</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>&nbsp;info@themeadows.com.pk</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-globe"></i></td>
                                    <td>&nbsp;www.themeadows.pk</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-map-marker"></i></td>
                                    <td>Office #8, Twin City Plaza, Seector 1-8 Markaz, Islamabad</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Site Office</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 334 9160272</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 51 486 2626</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>&nbsp;info@themeadows.com.pk</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-map-marker"></i></td>
                                    <td id="site_adress">Main Chak Beli Road, Near Vilage & Post Office Bhall, District & Tehsil Rawalpindi</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Lorem ipsum dolor sit amet</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92-123123123</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>imran@demo.com</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Lorem ipsum dolor sit amet</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92-123123123</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>Imran@demo.com</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> -->
            </div>
        </div>
    </div>

    <!---------CONTACT FORM ---------->

    <div class="ContactBody">
        <div class="content">
            <div class="container">
                <div class="row align-items-stretch no-gutters contact-wrap">
                    <div class="col-md-12">
                        <div class="form h-100">
                            <h3>CONTACT US</h3>
                            <form method="POST" action="" id="contactForm">
                                <div class="row">
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Name *</label>
                                        <input type="text" class="form-control" name="contact_fullname" id="name"
                                            placeholder="Your name">
                                    </div>
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Email *</label>
                                        <input type="text" class="form-control" name="contact_email" id="email"
                                            placeholder="Your email">
                                    </div>
                                </div>    
                                <div class="row mt-4">
                                <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Subject *</label>
                                        <input type="text" class="form-control" name="contact_subject" id="subject"
                                            placeholder="Your subject">
                                    </div>
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Contact No *</label>
                                        <input type="text" class="form-control" name="contact_no" id="contact"
                                            placeholder="Your contact no">
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-md-12 form-group mb-3">
                                        <label for="message" class="col-form-label">Message *</label>
                                        <textarea class="form-control" name="contact_message" id="message" cols="30" rows="4"
                                            placeholder="Write your message"></textarea>
                                    </div>
                                </div>
                                <div class="row" style="text-align:end;">
                                    <div class="col-md-12 form-group">
                                        <input type="submit" value="Send Message"
                                            class="btn btn-primary py-2 px-4" name="submit">
                                        <span class="submitting"></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </div>