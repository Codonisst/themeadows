<?php
// $conn= mysqli_connect('localhost','root','','meadows');

// if (isset($_POST['submit'])) 
// {
//     $name = $_POST['name'];
//     $email = $_POST['email'];
//     $message = $_POST['message'];
//     $insert = "INSERT INTO message(name,email,message) VALUES ('$name','$email','$message')";
//     $run = mysqli_query($conn,$insert) or die(mysqli_error($conn));
    
// }
// if($run)
// {
//     $to = "znigarmarwat@gmail.com";
//     $subject="thank you";
//     $message = "thanku for feedback";
//     $from = "From:znigarmarwat@gmail.com";
//     $email($to,$subject,$message,$from);
// }

?>








<div class="header-bottom">
        <div class="card text-white">
            <img class="card-img" src="assets/img/header_bottom.jpg" alt="Card image">
            <div class="card-img-overlay">
                <h2 class="card-title">CONTACT US</h2>
            </div>
        </div>
    </div>
</div>

    <div class="ContactDetails">
        <div class="SpacingBox"></div>
        <div class="SpacingBox"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Head Office</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 333 5933991</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 300 5041004</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>&nbsp;info@themeadows.com.pk</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-globe"></i></td>
                                    <td>&nbsp;www.themeadows.pk</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-map-marker"></i></td>
                                    <td>Office #8, Twin City Plaza, Seector 1-8 Markaz, Islamabad</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Site Office</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 334 9160272</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92 51 486 2626</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>&nbsp;info@themeadows.com.pk</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-map-marker"></i></td>
                                    <td id="site_adress">Main Chak Beli Road, Near Vilage & Post Office Bhall, District & Tehsil Rawalpindi</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Lorem ipsum dolor sit amet</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92-123123123</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>imran@demo.com</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                    <div class="Box">
                        <h4>Lorem ipsum dolor sit amet</h4>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td><i class="fa fa-phone"></i></td>
                                    <td>+92-123123123</td>
                                </tr>
                                <tr>
                                    <td><i class="fa fa-envelope"></i></td>
                                    <td>Imran@demo.com</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> -->
            </div>
        </div>
    </div>

    <!---------CONTACT FORM ---------->

    <div class="ContactBody">
        <div class="content">
            <div class="container">
                <div class="row align-items-stretch no-gutters contact-wrap">
                    <div class="col-md-12">
                        <div class="form h-100">
                            <h3>CONTACT US</h3>
                            <form method="post" id="contactForm" name="contactForm">
                                <div class="row">
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Name *</label>
                                        <input type="text" class="form-control" name="name" id="name"
                                            placeholder="Your name">
                                    </div>
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Email *</label>
                                        <input type="text" class="form-control" name="email" id="email"
                                            placeholder="Your email">
                                    </div>
                                    <!-- <div class="col-md-4 form-group mb-3">
                                        <label for="" class="col-form-label">Subject *</label>
                                        <input type="text" class="form-control" name="subject" id="subject"
                                            placeholder="Your subject">
                                    </div> -->
                                </div>    
                                <div class="row mt-4">
                                <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Subject *</label>
                                        <input type="text" class="form-control" name="subject" id="subject"
                                            placeholder="Your subject">
                                    </div>
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="" class="col-form-label">Contact No *</label>
                                        <input type="number" class="form-control" name="contact" id="contact"
                                            placeholder="Your contact no">
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-md-12 form-group mb-3">
                                        <label for="message" class="col-form-label">Message *</label>
                                        <textarea class="form-control" name="message" id="message" cols="30" rows="4"
                                            placeholder="Write your message"></textarea>
                                    </div>
                                </div>
                                <div class="row" style="text-align:end;">
                                    <div class="col-md-12 form-group">
                                        <input type="submit" value="Send Message"
                                            class="btn btn-primary py-2 px-4" name="submit">
                                        <span class="submitting"></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </div>